---
title: "References"
linkTitle: "References"
weight: 100
---

| Skaffold References  |
|----------|
| [CLI](/docs/references/cli) |
| [skaffold.yaml](/docs/references/yaml) |

