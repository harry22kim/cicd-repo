function echo(string) {
    return string;
}

module.exports = {
    echo
}