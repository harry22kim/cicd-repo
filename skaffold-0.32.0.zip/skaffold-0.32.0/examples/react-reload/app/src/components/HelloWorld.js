import React from 'react';
import '../styles/HelloWorld.css';

export const HelloWorld = () => (
	<div>
		<h1>Hello world!</h1>
	</div>
);
